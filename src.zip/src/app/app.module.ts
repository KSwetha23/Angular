import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { FeatureModuleModule } from './feature-module/feature-module.module';
import { NavigationSampleModule } from './navigation-sample/navigation-sample.module';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './navigation-sample/home/home.component';
import { ProjectsComponent } from './navigation-sample/projects/projects.component';
import { ServicesComponent } from './navigation-sample/services/services.component';
import { ContactComponent } from './navigation-sample/contact/contact.component';


const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'projects', component: ProjectsComponent},
  { path: 'services', component: ServicesComponent},
  { path: 'contact', component: ContactComponent}
]

@NgModule({
  declarations: [
    AppComponent  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    FeatureModuleModule,
    NavigationSampleModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true }
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
