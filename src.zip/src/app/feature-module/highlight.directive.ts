import { Directive, ElementRef, HostListener} from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})

export class HighlightDirective {
  
  constructor(private e :ElementRef)
  {

  } 

  private highlight(color: string) {
    this.e.nativeElement.style.backgroundColor = color;
  }
  @HostListener('mouseenter') onmouseenter() {
    this.highlight('blue');
  }
  
  @HostListener('mouseleave') onmouseleave() {
    this.highlight(null);
  }
}
